<?php

namespace App\Http\Controllers;

use App\Models\GradeLevel;
use App\Models\StockItem;
use App\Models\StockMovement;
use App\Models\Student;
use App\Services\StoreIssuer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StoreController
{
    public function __construct(private StoreIssuer $issuer)
    {
    }

    /* ------------------------------ reading ------------------------------ */

    /** The catalogue, with what is on the shelf for each item. */
    public function catalogue()
    {
        $onHand = StockItem::onHandMap();

        return response()->json([
            'categories' => StockItem::CATEGORIES,
            'items' => StockItem::with('gradeLevels:id,name')
                ->orderBy('category')->orderBy('name')
                ->get()
                ->map(fn (StockItem $i) => [
                    'id'            => $i->id,
                    'name'          => $i->name,
                    'category'      => $i->category,
                    'price'         => $i->price,
                    'per_student'   => $i->per_student,
                    'reorder_level' => $i->reorder_level,
                    'is_active'     => $i->is_active,
                    'on_hand'       => $onHand[$i->id] ?? 0,
                    'low'           => ($onHand[$i->id] ?? 0) <= $i->reorder_level,
                    // Empty means any grade may draw it.
                    'grade_levels'  => $i->gradeLevels->map->only(['id', 'name']),
                ]),
        ]);
    }

    /**
     * What this pupil's grade entitles them to, and what they have already
     * had. This is the store keeper's whole screen: he picks a pupil, and
     * the list that comes back is the list he is allowed to serve.
     */
    public function forStudent(Student $student)
    {
        $gradeLevel = $this->issuer->gradeLevelOf($student);
        $onHand = StockItem::onHandMap();

        $items = StockItem::with('gradeLevels:id')
            ->where('is_active', true)
            ->orderBy('category')->orderBy('name')
            ->get()
            ->filter(fn (StockItem $i) => $i->mayBeIssuedTo($gradeLevel?->id))
            ->values();

        return response()->json([
            'student' => [
                'id'          => $student->id,
                'name'        => $student->full_name,
                'grade_level' => $gradeLevel?->only(['id', 'name']),
            ],
            'items' => $items->map(function (StockItem $i) use ($student, $onHand) {
                $had = $i->issuedTo($student->id);
                $left = $onHand[$i->id] ?? 0;

                return [
                    'id'          => $i->id,
                    'name'        => $i->name,
                    'category'    => $i->category,
                    'price'       => $i->price,
                    'on_hand'     => $left,
                    'already_had' => $had,
                    'per_student' => $i->per_student,
                    // Say why, so the screen can grey the row out AND
                    // explain itself to the parent at the counter.
                    'issuable'    => $left > 0
                        && ($i->per_student === 0 || $had < $i->per_student),
                    'blocked_because' => $left <= 0
                        ? 'Out of stock'
                        : ($i->per_student > 0 && $had >= $i->per_student
                            ? 'Allowance already used this year'
                            : null),
                ];
            }),
        ]);
    }

    /**
     * The daily supply report — what the Proprietress sees on her dashboard.
     *
     * Summed by item, not listed issue by issue. What she needs at a glance
     * is "eleven uniforms went out today", not eleven rows; the rows are on
     * the store page for when she wants them.
     */
    public function dailyReport(Request $request)
    {
        $data = $request->validate(['date' => ['nullable', 'date']]);
        $date = $data['date'] ?? now()->toDateString();

        $issues = StockMovement::issued()->on($date)
            ->with(['student:id,first_name,last_name', 'recorder:id,name'])
            ->orderBy('created_at')
            ->get();

        $byItem = $issues->groupBy('description')
            ->map(fn ($rows) => (int) $rows->sum('qty'))
            ->sortDesc();

        $onHand = StockItem::onHandMap();

        $low = StockItem::where('is_active', true)->get()
            ->filter(fn (StockItem $i) => ($onHand[$i->id] ?? 0) <= $i->reorder_level)
            ->sortBy(fn (StockItem $i) => $onHand[$i->id] ?? 0)
            ->values()
            ->map(fn (StockItem $i) => [
                'id'            => $i->id,
                'name'          => $i->name,
                'on_hand'       => $onHand[$i->id] ?? 0,
                'reorder_level' => $i->reorder_level,
            ]);

        return response()->json([
            'date'             => $date,
            'issues'           => $issues->count(),
            'units'            => (int) $issues->sum('qty'),
            'students_served'  => $issues->pluck('student_id')->unique()->count(),
            'by_item'          => $byItem,
            'rows'             => $issues->map(fn (StockMovement $m) => [
                'at'      => $m->created_at->format('H:i'),
                'student' => $m->student?->full_name ?? 'Removed pupil',
                'item'    => $m->description,
                'qty'     => $m->qty,
                'by'      => $m->recorder?->name,
            ]),
            'low_stock'        => $low,
        ]);
    }

    /** Every movement for one item — the answer to "where did they go?". */
    public function ledger(StockItem $item)
    {
        return response()->json([
            'item'    => ['id' => $item->id, 'name' => $item->name],
            'on_hand' => $item->onHand(),
            'rows'    => $item->movements()
                ->with(['student:id,first_name,last_name', 'recorder:id,name'])
                ->orderByDesc('occurred_on')->orderByDesc('id')
                ->limit(200)
                ->get()
                ->map(fn (StockMovement $m) => [
                    'date'      => $m->occurred_on->toDateString(),
                    'direction' => $m->direction,
                    'qty'       => $m->qty,
                    'student'   => $m->student?->full_name,
                    'note'      => $m->note,
                    'by'        => $m->recorder?->name,
                ]),
        ]);
    }

    /* --------------------- the store keeper's one verb --------------------- */

    public function issue(Request $request)
    {
        $data = $request->validate([
            'student_id'    => ['required', 'exists:students,id'],
            'stock_item_id' => ['required', 'exists:stock_items,id'],
            'qty'           => ['required', 'integer', 'min:1'],
            'note'          => ['nullable', 'string', 'max:200'],
        ]);

        $movement = $this->issuer->issue(
            Student::findOrFail($data['student_id']),
            StockItem::findOrFail($data['stock_item_id']),
            $data['qty'],
            $data['note'] ?? null
        );

        return response()->json([
            'message' => "{$movement->qty} × {$movement->description} issued.",
            'on_hand' => $movement->item->onHand(),
        ], 201);
    }

    /* ------------------- the Proprietress's two verbs ------------------- */

    public function receive(Request $request)
    {
        $data = $request->validate([
            'stock_item_id' => ['required', 'exists:stock_items,id'],
            'qty'           => ['required', 'integer', 'min:1'],
            'note'          => ['nullable', 'string', 'max:200'],
        ]);

        $item = StockItem::findOrFail($data['stock_item_id']);
        $this->issuer->receive($item, $data['qty'], $data['note'] ?? null);

        return response()->json([
            'message' => "{$data['qty']} × {$item->name} received.",
            'on_hand' => $item->onHand(),
        ], 201);
    }

    public function storeItem(Request $request)
    {
        $data = $this->validateItem($request);

        $item = DB::transaction(function () use ($data) {
            $item = StockItem::create($data);
            $item->gradeLevels()->sync($data['grade_level_ids'] ?? []);

            // An opening count is not a special column — it is the first
            // delivery in, so even the starting figure says where it came
            // from and who put it there.
            if (! empty($data['opening'])) {
                $this->issuer->receive($item, (int) $data['opening'], 'Opening stock');
            }

            return $item;
        });

        return response()->json(['message' => "{$item->name} added.", 'id' => $item->id], 201);
    }

    public function updateItem(Request $request, StockItem $item)
    {
        $data = $this->validateItem($request, $item);

        $item->update($data);

        if ($request->has('grade_level_ids')) {
            $item->gradeLevels()->sync($data['grade_level_ids'] ?? []);
        }

        return response()->json(['message' => "{$item->name} updated."]);
    }

    /**
     * Items are retired, never deleted: movements point at them, and a
     * report from last term must still be able to say what was handed over.
     */
    public function retireItem(StockItem $item)
    {
        $item->update(['is_active' => false]);

        return response()->json([
            'message' => "{$item->name} retired. Its history is kept.",
        ]);
    }

    private function validateItem(Request $request, ?StockItem $item = null): array
    {
        $unique = 'unique:stock_items,name' . ($item ? ',' . $item->id : '');

        return $request->validate([
            'name'             => ['required', 'string', 'max:120', $unique],
            'category'         => ['required', 'in:' . implode(',', StockItem::CATEGORIES)],
            'price'            => ['nullable', 'numeric', 'min:0'],
            'per_student'      => ['nullable', 'integer', 'min:0', 'max:9999'],
            'reorder_level'    => ['nullable', 'integer', 'min:0', 'max:9999'],
            'is_active'        => ['nullable', 'boolean'],
            'opening'          => ['nullable', 'integer', 'min:0'],
            'grade_level_ids'  => ['nullable', 'array'],
            'grade_level_ids.*' => ['integer', 'exists:grade_levels,id'],
        ]);
    }
}
