<?php

namespace App\Services;

use App\Models\AcademicYear;
use App\Models\StockItem;
use App\Models\StockMovement;
use App\Models\Student;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * Handing something over the counter.
 *
 * Every refusal here is a refusal the store keeper would otherwise have to
 * remember: the wrong grade, the second uniform, the shelf that is already
 * empty. Putting the store in the portal is only worth doing if the screen
 * says no on his behalf — and says it in words he can repeat to the parent
 * standing in front of him.
 */
class StoreIssuer
{
    /**
     * Issue an item to a pupil.
     *
     * The whole check-and-write runs inside a transaction with the item row
     * locked. Two people at two counters issuing the last uniform at the
     * same moment is not a hypothetical in the first week of term: both
     * would read "1 left", both would pass the check, and the ledger would
     * go to -1 with nothing to show which sale was the phantom.
     */
    public function issue(Student $student, StockItem $item, int $qty, ?string $note = null): StockMovement
    {
        if ($qty < 1) {
            $this->fail('qty', 'Enter a quantity of at least one.');
        }

        if (! $item->is_active) {
            $this->fail('stock_item_id', "{$item->name} is no longer stocked.");
        }

        $gradeLevel = $this->gradeLevelOf($student);

        if (! $item->mayBeIssuedTo($gradeLevel?->id)) {
            $this->fail('stock_item_id', sprintf(
                '%s is not issued to %s.',
                $item->name,
                $gradeLevel?->name ?? 'a pupil with no current class'
            ));
        }

        return DB::transaction(function () use ($student, $item, $qty, $note) {
            // Lock the item, then recompute from the ledger inside the lock.
            $item = StockItem::whereKey($item->id)->lockForUpdate()->firstOrFail();

            $onHand = $item->onHand();

            if ($qty > $onHand) {
                $this->fail('qty', $onHand > 0
                    ? "Only {$onHand} left on the shelf."
                    : "{$item->name} is out of stock.");
            }

            if ($item->per_student > 0) {
                $since = AcademicYear::where('is_current', true)->value('start_date');
                $had = $item->issuedTo($student->id, $since);

                if ($had + $qty > $item->per_student) {
                    $this->fail('qty', sprintf(
                        '%s has already had %d this year. The allowance is %d.',
                        $student->full_name, $had, $item->per_student
                    ));
                }
            }

            return StockMovement::create([
                'stock_item_id' => $item->id,
                'direction'     => StockMovement::OUT,
                'qty'           => $qty,
                'student_id'    => $student->id,
                'description'   => $item->name,   // copied, not referenced
                'note'          => $note,
                'recorded_by'   => Auth::id(),
                'occurred_on'   => now()->toDateString(),
            ]);
        });
    }

    /** A delivery in. The Proprietress's side of the ledger. */
    public function receive(StockItem $item, int $qty, ?string $note = null): StockMovement
    {
        if ($qty < 1) {
            $this->fail('qty', 'Enter a quantity of at least one.');
        }

        return StockMovement::create([
            'stock_item_id' => $item->id,
            'direction'     => StockMovement::IN,
            'qty'           => $qty,
            'description'   => $item->name,
            'note'          => $note,
            'recorded_by'   => Auth::id(),
            'occurred_on'   => now()->toDateString(),
        ]);
    }

    /**
     * The pupil's grade, through their most recent enrolment. Null if they
     * have never been enrolled — which is a real state for a pupil admitted
     * but not yet placed, and must not quietly read as "any grade".
     */
    public function gradeLevelOf(Student $student)
    {
        return $student->enrollments()
            ->with('classRoom.gradeLevel')
            ->first()?->classRoom?->gradeLevel;
    }

    private function fail(string $field, string $message): void
    {
        throw ValidationException::withMessages([$field => $message]);
    }
}
