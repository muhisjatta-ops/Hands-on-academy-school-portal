<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StockItem extends Model
{
    public const CATEGORIES = ['Books', 'Uniform', 'Stationery', 'Equipment'];

    protected $fillable = [
        'name', 'category', 'price', 'per_student', 'reorder_level', 'is_active',
    ];

    protected $casts = [
        'price'     => 'decimal:2',
        'is_active' => 'boolean',
    ];

    public function gradeLevels()
    {
        return $this->belongsToMany(GradeLevel::class);
    }

    public function movements()
    {
        return $this->hasMany(StockMovement::class);
    }

    /**
     * What is on the shelf.
     *
     * Computed, never stored. Two aggregate queries rather than a column,
     * which is cheap at a school's volumes and means the figure can always
     * be traced back to the rows that produced it.
     */
    public function onHand(): int
    {
        $in = (int) $this->movements()->where('direction', 'IN')->sum('qty');
        $out = (int) $this->movements()->where('direction', 'OUT')->sum('qty');

        return $in - $out;
    }

    /** On-hand for many items at once, without a query per row. */
    public static function onHandMap(): array
    {
        $rows = StockMovement::query()
            ->selectRaw('stock_item_id, direction, SUM(qty) as total')
            ->groupBy('stock_item_id', 'direction')
            ->get();

        $map = [];

        foreach ($rows as $row) {
            $map[$row->stock_item_id] = ($map[$row->stock_item_id] ?? 0)
                + ($row->direction === 'IN' ? (int) $row->total : -(int) $row->total);
        }

        return $map;
    }

    /** No grades listed means general stock: anyone may draw it. */
    public function mayBeIssuedTo(?int $gradeLevelId): bool
    {
        $scoped = $this->gradeLevels()->pluck('grade_levels.id');

        if ($scoped->isEmpty()) {
            return true;
        }

        return $gradeLevelId !== null && $scoped->contains($gradeLevelId);
    }

    /** How many of this item a pupil has had since a given date. */
    public function issuedTo(int $studentId, ?string $since = null): int
    {
        return (int) $this->movements()
            ->where('direction', 'OUT')
            ->where('student_id', $studentId)
            ->when($since, fn ($q) => $q->where('occurred_on', '>=', $since))
            ->sum('qty');
    }

    public function isLow(?int $onHand = null): bool
    {
        return ($onHand ?? $this->onHand()) <= $this->reorder_level;
    }
}
