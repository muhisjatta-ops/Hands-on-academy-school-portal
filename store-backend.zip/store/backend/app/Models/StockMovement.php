<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * One movement of stock. Append-only by intent: there is no update path in
 * the controller and none should be added. A delivery entered wrongly is
 * corrected by a second movement in the other direction with a note saying
 * why, exactly as a payment is reversed rather than edited — so the trail
 * shows the mistake and the correction, not a tidied-up history.
 */
class StockMovement extends Model
{
    public const IN = 'IN';
    public const OUT = 'OUT';

    protected $fillable = [
        'stock_item_id', 'direction', 'qty', 'student_id',
        'description', 'note', 'recorded_by', 'occurred_on',
    ];

    protected $casts = ['occurred_on' => 'date'];

    public function item()
    {
        return $this->belongsTo(StockItem::class, 'stock_item_id');
    }

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function recorder()
    {
        return $this->belongsTo(User::class, 'recorded_by');
    }

    public function scopeIssued($query)
    {
        return $query->where('direction', self::OUT);
    }

    public function scopeOn($query, string $date)
    {
        return $query->whereDate('occurred_on', $date);
    }
}
