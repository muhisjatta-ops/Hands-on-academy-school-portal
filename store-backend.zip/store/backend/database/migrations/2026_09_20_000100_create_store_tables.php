<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * The school store: book shop and uniform shop.
 *
 * There is no `quantity_on_hand` column anywhere in here, and that is the
 * whole design. Stock is an append-only ledger, the same as money: an item
 * is defined once, and every movement after that is a row. What is on the
 * shelf is `sum(IN) - sum(OUT)`, computed on read.
 *
 * A stored quantity is a number somebody can quietly correct, and a store
 * whose figures can be quietly corrected cannot answer the only question
 * that matters when a count comes up short: who took it, and when. It also
 * makes the permission split the school asked for fall out for free — the
 * Proprietress writes IN rows, the store keeper writes OUT rows, and
 * neither of them edits a balance, because there is no balance to edit.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('stock_items', function (Blueprint $table) {
            $table->id();
            $table->string('name', 120);
            $table->string('category', 40);              // Books, Uniform, …
            $table->decimal('price', 10, 2)->default(0); // what the bill charges

            // 0 means no limit. One uniform per pupil per year is the rule
            // this encodes; a pack of exercise books is not limited.
            $table->unsignedSmallInteger('per_student')->default(1);

            // Warn the Proprietress at this level. Not a hard stop: running
            // out is a fact, and the ledger should record it, not hide it.
            $table->unsignedSmallInteger('reorder_level')->default(0);

            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->unique('name');
        });

        /*
         * Which grades an item may be issued to — "supply by grade", as a
         * table rather than a rule in someone's head. An item with NO rows
         * here is general stock any pupil may draw; that absence is
         * deliberate and is checked for explicitly in the service.
         */
        Schema::create('stock_item_grade_level', function (Blueprint $table) {
            $table->foreignId('stock_item_id')->constrained()->cascadeOnDelete();
            $table->foreignId('grade_level_id')->constrained()->cascadeOnDelete();

            $table->primary(['stock_item_id', 'grade_level_id']);
        });

        Schema::create('stock_movements', function (Blueprint $table) {
            $table->id();
            $table->foreignId('stock_item_id')->constrained()->restrictOnDelete();

            // IN  — a delivery received, or the opening count.
            // OUT — issued to a pupil.
            $table->string('direction', 3);

            // Always positive. The direction carries the sign, so nobody can
            // cancel an issue by typing a negative quantity into it.
            $table->unsignedInteger('qty');

            // Only set on OUT rows. An issue with no pupil is a loss, and
            // should be recorded as one, deliberately.
            $table->foreignId('student_id')->nullable()
                ->constrained()->restrictOnDelete();

            // The item's name AS IT WAS on the day, copied not referenced.
            // Rename "Uniform set · Grade 7" next year and last year's
            // report still says what was actually handed over.
            $table->string('description', 120);

            $table->string('note', 200)->nullable();     // supplier, invoice, reason

            $table->foreignId('recorded_by')->nullable()
                ->constrained('users')->nullOnDelete();

            $table->date('occurred_on');
            $table->timestamps();

            // The three questions: what is on the shelf, what went out
            // today, and what has this pupil already had.
            $table->index(['stock_item_id', 'direction']);
            $table->index(['occurred_on', 'direction']);
            $table->index(['student_id', 'stock_item_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_movements');
        Schema::dropIfExists('stock_item_grade_level');
        Schema::dropIfExists('stock_items');
    }
};
