<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

/**
 * Permissions are verbs on nouns: "students.view", "fees.record_payment".
 * Roles are bundles of those verbs. Code should check PERMISSIONS, not roles
 * — then the head teacher can grant a clerk one extra ability without you
 * shipping a new release.
 *
 * The one thing RBAC cannot express is SCOPE: "a teacher may enter scores,
 * but only for classes they teach". That is a row-level rule and belongs in
 * a Laravel Policy, not here. Keep the two ideas separate.
 *
 * Re-running is safe: findOrCreate leaves existing rows alone and
 * syncPermissions brings each role back to the list below. Anything granted
 * to a role by hand in the meantime is removed, which is the point — this
 * file is the record of who may do what.
 */
class RolePermissionSeeder extends Seeder
{
    public function run(): void
    {
        $permissions = [
            // students
            'students.view', 'students.create', 'students.update',
            'students.delete', 'students.export',
            // academics
            'classes.manage', 'subjects.manage',
            'assessments.manage', 'scores.enter', 'scores.publish',
            'reports.generate',
            // fees
            'fees.view', 'fees.structure_manage', 'fees.invoice_generate',
            'fees.record_payment', 'fees.void_payment', 'fees.discount_grant',
            // attendance — pupils
            'attendance.view', 'attendance.record',
            // the school store — book shop and uniform shop. Three verbs,
            // because the school asked for three different people: anyone
            // who may look at the shelf, the one person who defines items
            // and receives deliveries, and the one who hands things over.
            'store.view', 'store.manage', 'store.issue',
            // attendance — staff. Separate verbs from the pupil register:
            // the people who may mark children present are not the people
            // who may record that a colleague did not come to work.
            'staff-attendance.view', 'staff-attendance.record',
            // admin
            'users.manage', 'roles.manage', 'audit.view', 'settings.manage',
        ];

        foreach ($permissions as $name) {
            Permission::findOrCreate($name);
        }

        $roles = [
            'super-admin' => $permissions,

            /*
             * The Proprietress. She READS the staff register but does not
             * mark it — the school asked for the principal to keep it, and a
             * register with two keepers is a register nobody keeps. Add
             * 'staff-attendance.record' to this diff's exceptions if she
             * should be able to correct a mark herself.
             */
            'admin' => array_diff($permissions, [
                'fees.void_payment',
                'roles.manage',
                'staff-attendance.record',
                // She is the inventory manager, not the counter. She adds
                // items, sets prices and records deliveries; the store
                // keeper hands them over. Remove this line to let her serve
                // a pupil when he is away.
                'store.issue',
            ]),

            /*
             * The Principal. A teacher's permissions plus the staff
             * register, plus school-wide marks and reports — a head who
             * cannot see the whole school cannot run it.
             */
            'principal' => [
                'students.view', 'students.export',
                'assessments.manage', 'scores.enter', 'scores.publish',
                'reports.generate',
                'attendance.view', 'attendance.record',
                'staff-attendance.view', 'staff-attendance.record',
            ],

            /*
             * The store keeper. One verb and nothing else: he may hand a
             * pupil what their grade entitles them to. He cannot invent an
             * item, change a price, or record a delivery he did not
             * receive — which is exactly what makes a stock count mean
             * something at the end of term.
             */
            'storekeeper' => [
                'students.view',
                'store.view', 'store.issue',
            ],

            'bursar' => [
                'students.view',
                'store.view',
                'fees.view', 'fees.structure_manage', 'fees.invoice_generate',
                'fees.record_payment', 'fees.void_payment', 'fees.discount_grant',
                'audit.view',
            ],

            /*
             * Teachers are NOT given staff-attendance.view. Who was absent
             * is a staffing matter between a person and their head, not
             * something the whole common room reads off a screen.
             */
            'teacher' => [
                'students.view',
                'assessments.manage', 'scores.enter',
                'attendance.view', 'attendance.record',
                'reports.generate',
            ],

            'registrar' => [
                'students.view', 'students.create', 'students.update',
                'students.export', 'classes.manage', 'attendance.view',
            ],

            'parent' => ['students.view', 'fees.view', 'attendance.view'],

            'student' => ['attendance.view'],
        ];

        foreach ($roles as $role => $granted) {
            Role::findOrCreate($role)->syncPermissions($granted);
        }

        $this->command?->info(count($permissions) . ' permissions across '
            . count($roles) . ' roles.');
        $this->command?->warn(
            'Two deliberate gaps in the administrator role: she reads the '
            . 'staff register but does not mark it, and she manages the store '
            . 'but does not issue from it. See the comments on that role.'
        );
    }
}
