<?php

namespace Database\Seeders;

use App\Models\GradeLevel;
use App\Models\StockItem;
use Illuminate\Database\Seeder;

/**
 * The store catalogue, built from the school's own bill.
 *
 * Every item here exists because the school charges for it, and it is
 * issued to exactly the levels that pay for it. That is not a convenience —
 * it is the only definition of "what this grade is entitled to" that the
 * school has already agreed and printed, and inventing a second one in
 * code would guarantee the two disagree within a term.
 *
 *     php artisan db:seed --class=StoreCatalogueSeeder
 *
 * Run HandsOnFeeSeeder first: this one matches grade levels by name and
 * skips any it cannot find. Re-running updates prices and grade scoping
 * and never touches stock — quantities only ever change by a movement.
 */
class StoreCatalogueSeeder extends Seeder
{
    /**
     * Fee line => what the store calls it, and its category.
     *
     * Only lines that correspond to something physically handed over the
     * counter. "Development fee" buys no object, so it is not here.
     */
    private const FROM_FEES = [
        'Book bill'    => ['Book pack', 'Books'],
        'Uniform'      => ['Uniform set', 'Uniform'],
        'Stationeries' => ['Stationery pack', 'Stationery'],
        'Abacus'       => ['Abacus', 'Equipment'],
    ];

    /**
     * The charge for each physical item, by level, straight from the
     * 2026/2027 bill. A level absent from a row is not charged for that
     * item and therefore is not issued it.
     */
    private const SCHEDULE = [
        'ECD Daycare' => ['Stationeries' => 500,  'Uniform' => 1500],
        'ECD Level 1' => ['Stationeries' => 500,  'Uniform' => 1500],
        'ECD Level 2' => ['Stationeries' => 500,  'Uniform' => 1500],
        'ECD Level 3' => ['Stationeries' => 500,  'Uniform' => 1500],
        'Grade 1-3'   => ['Book bill' => 1700, 'Uniform' => 1600, 'Abacus' => 700],
        'Grade 4-6'   => ['Book bill' => 1700, 'Uniform' => 1600, 'Abacus' => 700],
        'Grade 7'     => ['Book bill' => 3500, 'Uniform' => 2500],
        'Grade 8'     => ['Book bill' => 3500, 'Uniform' => 2500],
        // Grade 9 is charged for no physical item on the published bill —
        // no book bill, no uniform. That is what the paper says, so it is
        // what the store says. Flagged at the end of this run, because a
        // leaving year that genuinely needs neither is unusual and the
        // accounts office should confirm it rather than discover it.
        'Grade 9'     => [],
    ];

    public function run(): void
    {
        $created = 0;
        $updated = 0;
        $missing = [];

        foreach (self::SCHEDULE as $levelName => $charges) {
            $level = GradeLevel::where('name', $levelName)->first();

            if (! $level) {
                $missing[] = $levelName;
                continue;
            }

            foreach ($charges as $feeLine => $price) {
                [$label, $category] = self::FROM_FEES[$feeLine];
                $name = "{$label} · {$levelName}";

                $item = StockItem::where('name', $name)->first();

                if ($item) {
                    $item->update([
                        'category' => $category,
                        'price'    => $price,
                    ]);
                    $updated++;
                } else {
                    $item = StockItem::create([
                        'name'          => $name,
                        'category'      => $category,
                        'price'         => $price,
                        'per_student'   => 1,   // one uniform per pupil per year
                        'reorder_level' => 5,
                        'is_active'     => true,
                    ]);
                    $created++;
                }

                // Scoped to this level and no other. A Grade 7 uniform is
                // not a Grade 1 uniform, and the store keeper should not
                // have to remember which is which at the counter.
                $item->gradeLevels()->sync([$level->id]);
            }
        }

        $this->command->info("{$created} item(s) created, {$updated} updated.");

        if ($missing) {
            $this->command->warn(
                'No grade level found for: ' . implode(', ', $missing)
                . ' — run HandsOnFeeSeeder first.'
            );
        }

        $this->command->warn(
            'Grade 9 has no store items: the published bill charges it for no '
            . 'book pack and no uniform. Confirm with the accounts office.'
        );
        $this->command->warn(
            'Every item starts at zero on hand. Record the opening count as a '
            . 'delivery (POST /api/store/receive) so the figure says where it '
            . 'came from.'
        );
    }
}
