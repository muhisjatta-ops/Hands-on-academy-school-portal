<?php

namespace Tests\Feature;

use App\Models\AcademicYear;
use App\Models\ClassRoom;
use App\Models\Enrollment;
use App\Models\GradeLevel;
use App\Models\StockItem;
use App\Models\StockMovement;
use App\Models\Student;
use App\Models\User;
use App\Services\StoreIssuer;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

/**
 * The store, asserted both ways.
 *
 * Each permission case has its mirror: the Proprietress can add an item
 * AND cannot issue one; the store keeper can issue AND cannot add. A test
 * that only proves the permitted case would still pass if everybody were
 * permitted, which is the failure mode that matters here.
 */
class StoreTest extends TestCase
{
    use RefreshDatabase;

    private User $proprietress;
    private User $storekeeper;
    private User $teacher;

    private GradeLevel $grade7;
    private GradeLevel $grade1;
    private Student $pupil7;
    private StockItem $uniform7;
    private StockItem $uniform1;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RolePermissionSeeder::class);

        $this->proprietress = $this->userWith('admin');
        $this->storekeeper = $this->userWith('storekeeper');
        $this->teacher = $this->userWith('teacher');

        $year = AcademicYear::create([
            'name' => '2026/2027', 'start_date' => now()->startOfYear(),
            'end_date' => now()->endOfYear(), 'is_current' => true,
        ]);

        $this->grade7 = GradeLevel::create(['name' => 'Grade 7', 'sequence' => 7]);
        $this->grade1 = GradeLevel::create(['name' => 'Grade 1-3', 'sequence' => 5]);

        $this->pupil7 = $this->pupilIn($this->grade7, $year, 'Ebrima', 'Camara');

        $this->uniform7 = $this->item('Uniform set · Grade 7', 2500, $this->grade7, 40);
        $this->uniform1 = $this->item('Uniform set · Grade 1-3', 1600, $this->grade1, 40);
    }

    /* ------------------------ who may do what ------------------------ */

    public function test_store_keeper_can_issue(): void
    {
        $this->actingAs($this->storekeeper)
            ->postJson('/api/store/issue', [
                'student_id'    => $this->pupil7->id,
                'stock_item_id' => $this->uniform7->id,
                'qty'           => 1,
            ])
            ->assertCreated()
            ->assertJsonPath('on_hand', 39);
    }

    public function test_store_keeper_cannot_add_an_item(): void
    {
        $this->actingAs($this->storekeeper)
            ->postJson('/api/store/items', [
                'name' => 'Invented item', 'category' => 'Books',
            ])
            ->assertForbidden();

        $this->assertDatabaseMissing('stock_items', ['name' => 'Invented item']);
    }

    public function test_store_keeper_cannot_record_a_delivery(): void
    {
        $this->actingAs($this->storekeeper)
            ->postJson('/api/store/receive', [
                'stock_item_id' => $this->uniform7->id, 'qty' => 500,
            ])
            ->assertForbidden();

        $this->assertSame(40, $this->uniform7->onHand());
    }

    public function test_proprietress_can_add_an_item_and_receive_stock(): void
    {
        $this->actingAs($this->proprietress)
            ->postJson('/api/store/items', [
                'name' => 'Exercise books', 'category' => 'Stationery',
                'price' => 50, 'per_student' => 0, 'opening' => 200,
            ])
            ->assertCreated();

        $item = StockItem::where('name', 'Exercise books')->firstOrFail();

        // The opening count is a movement, not a column.
        $this->assertSame(200, $item->onHand());
        $this->assertDatabaseHas('stock_movements', [
            'stock_item_id' => $item->id, 'direction' => 'IN', 'note' => 'Opening stock',
        ]);
    }

    public function test_proprietress_cannot_issue(): void
    {
        $this->actingAs($this->proprietress)
            ->postJson('/api/store/issue', [
                'student_id'    => $this->pupil7->id,
                'stock_item_id' => $this->uniform7->id,
                'qty'           => 1,
            ])
            ->assertForbidden();

        $this->assertSame(40, $this->uniform7->onHand());
    }

    public function test_a_teacher_cannot_see_the_store_at_all(): void
    {
        $this->actingAs($this->teacher)->getJson('/api/store/catalogue')->assertForbidden();
        $this->actingAs($this->teacher)->getJson('/api/store/report')->assertForbidden();
    }

    /* ------------------------- supply by grade ------------------------- */

    public function test_a_pupil_is_offered_only_their_own_grades_items(): void
    {
        $response = $this->actingAs($this->storekeeper)
            ->getJson('/api/store/students/' . $this->pupil7->id)
            ->assertOk()
            ->assertJsonPath('student.grade_level.name', 'Grade 7');

        $names = collect($response->json('items'))->pluck('name');

        $this->assertContains('Uniform set · Grade 7', $names);
        $this->assertNotContains('Uniform set · Grade 1-3', $names);
    }

    public function test_issuing_another_grades_item_is_refused_by_name(): void
    {
        $this->actingAs($this->storekeeper)
            ->postJson('/api/store/issue', [
                'student_id'    => $this->pupil7->id,
                'stock_item_id' => $this->uniform1->id,   // the wrong uniform
                'qty'           => 1,
            ])
            ->assertStatus(422)
            ->assertJsonValidationErrors('stock_item_id');

        // Refused, and the shelf is untouched.
        $this->assertSame(40, $this->uniform1->onHand());
    }

    public function test_an_item_with_no_grades_listed_is_general_stock(): void
    {
        $pencils = $this->item('Pencils', 10, null, 100);

        $names = collect(
            $this->actingAs($this->storekeeper)
                ->getJson('/api/store/students/' . $this->pupil7->id)
                ->json('items')
        )->pluck('name');

        $this->assertContains('Pencils', $names);
        $this->assertSame(100, $pencils->onHand());
    }

    /* --------------------------- the allowance --------------------------- */

    public function test_a_second_uniform_is_refused_with_the_count_in_the_message(): void
    {
        $this->issueOne();

        $response = $this->actingAs($this->storekeeper)
            ->postJson('/api/store/issue', [
                'student_id'    => $this->pupil7->id,
                'stock_item_id' => $this->uniform7->id,
                'qty'           => 1,
            ])
            ->assertStatus(422);

        $this->assertStringContainsString(
            'already had 1',
            $response->json('errors.qty.0')
        );
    }

    public function test_an_allowance_of_zero_means_no_limit(): void
    {
        $pencils = $this->item('Pencils', 10, null, 100, 0);

        foreach (range(1, 3) as $ignored) {
            $this->actingAs($this->storekeeper)
                ->postJson('/api/store/issue', [
                    'student_id'    => $this->pupil7->id,
                    'stock_item_id' => $pencils->id,
                    'qty'           => 2,
                ])
                ->assertCreated();
        }

        $this->assertSame(94, $pencils->onHand());
    }

    /* ------------------------------ the shelf ------------------------------ */

    public function test_the_store_cannot_issue_what_it_does_not_have(): void
    {
        $empty = $this->item('Ties', 100, null, 0);

        $this->actingAs($this->storekeeper)
            ->postJson('/api/store/issue', [
                'student_id'    => $this->pupil7->id,
                'stock_item_id' => $empty->id,
                'qty'           => 1,
            ])
            ->assertStatus(422)
            ->assertJsonValidationErrors('qty');
    }

    public function test_on_hand_is_deliveries_less_issues(): void
    {
        $this->issueOne();

        $this->actingAs($this->proprietress)
            ->postJson('/api/store/receive', [
                'stock_item_id' => $this->uniform7->id, 'qty' => 10,
            ])
            ->assertCreated();

        // 40 opening + 10 in - 1 out
        $this->assertSame(49, $this->uniform7->onHand());
    }

    public function test_retiring_an_item_keeps_its_history(): void
    {
        $this->issueOne();

        $this->actingAs($this->proprietress)
            ->deleteJson('/api/store/items/' . $this->uniform7->id)
            ->assertOk();

        $this->assertFalse($this->uniform7->fresh()->is_active);

        // Its own two rows survive: the opening count and the issue.
        $this->assertSame(2, $this->uniform7->movements()->count());
    }

    /* --------------------------- the daily report --------------------------- */

    public function test_the_daily_report_sums_by_item_for_the_dashboard(): void
    {
        $this->issueOne(1);

        $second = $this->pupilIn($this->grade7, AcademicYear::first(), 'Isatou', 'Bah');
        $this->actingAs($this->storekeeper)->postJson('/api/store/issue', [
            'student_id' => $second->id, 'stock_item_id' => $this->uniform7->id, 'qty' => 1,
        ])->assertCreated();

        $this->actingAs($this->proprietress)
            ->getJson('/api/store/report')
            ->assertOk()
            ->assertJsonPath('units', 2)
            ->assertJsonPath('students_served', 2)
            ->assertJsonPath('by_item.Uniform set · Grade 7', 2);
    }

    public function test_the_report_covers_one_day_only(): void
    {
        StockMovement::create([
            'stock_item_id' => $this->uniform7->id, 'direction' => 'OUT', 'qty' => 5,
            'student_id' => $this->pupil7->id, 'description' => $this->uniform7->name,
            'occurred_on' => now()->subDay()->toDateString(),
        ]);

        $this->actingAs($this->proprietress)
            ->getJson('/api/store/report')
            ->assertOk()
            ->assertJsonPath('units', 0);

        $this->actingAs($this->proprietress)
            ->getJson('/api/store/report?date=' . now()->subDay()->toDateString())
            ->assertOk()
            ->assertJsonPath('units', 5);
    }

    public function test_low_stock_is_flagged_on_the_report(): void
    {
        // A uniform is one per pupil per year, so emptying the shelf in one
        // go means lifting that limit first — which is the Proprietress's
        // call to make, and a fair use of her role in a test.
        $this->uniform7->update(['per_student' => 0]);

        $this->issueOne(37);   // 40 - 37 = 3, against a reorder level of 5

        $low = $this->actingAs($this->proprietress)
            ->getJson('/api/store/report')
            ->assertOk()
            ->json('low_stock');

        $this->assertSame('Uniform set · Grade 7', $low[0]['name']);
        $this->assertSame(3, $low[0]['on_hand']);
    }

    /* ----------------------------- the record ----------------------------- */

    public function test_an_issue_records_who_and_keeps_the_name_of_the_day(): void
    {
        $this->issueOne();

        $movement = StockMovement::issued()->firstOrFail();

        $this->assertSame($this->storekeeper->id, $movement->recorded_by);
        $this->assertSame('Uniform set · Grade 7', $movement->description);

        // Rename the item; the movement still says what was handed over.
        $this->uniform7->update(['name' => 'Uniform set · Upper Basic']);

        $this->assertSame('Uniform set · Grade 7', $movement->fresh()->description);
    }

    public function test_a_pupil_with_no_class_is_not_treated_as_any_grade(): void
    {
        $unplaced = Student::create([
            'admission_number' => 'HOA-2026-9999', 'first_name' => 'Not', 'last_name' => 'Placed',
            'date_of_birth' => '2014-01-01', 'gender' => 'Male',
            'admission_date' => now(), 'status' => 'ACTIVE',
        ]);

        $this->expectException(ValidationException::class);

        app(StoreIssuer::class)->issue($unplaced, $this->uniform7, 1);
    }

    /* ------------------------------- helpers ------------------------------- */

    private function userWith(string $role): User
    {
        $user = User::factory()->create();
        $user->assignRole($role);

        return $user;
    }

    private function pupilIn(GradeLevel $level, AcademicYear $year, string $first, string $last): Student
    {
        $student = Student::create([
            'admission_number' => 'HOA-' . fake()->unique()->numerify('####'),
            'first_name' => $first, 'last_name' => $last,
            'date_of_birth' => '2013-05-01', 'gender' => 'Male',
            'admission_date' => now(), 'status' => 'ACTIVE',
        ]);

        $class = ClassRoom::create([
            'grade_level_id' => $level->id, 'academic_year_id' => $year->id,
            'stream' => 'Blue', 'capacity' => 40,
        ]);

        Enrollment::create([
            'student_id' => $student->id, 'class_room_id' => $class->id,
            'academic_year_id' => $year->id, 'date_enrolled' => now(),
        ]);

        return $student;
    }

    private function item(string $name, int $price, ?GradeLevel $level, int $opening, int $cap = 1): StockItem
    {
        $item = StockItem::create([
            'name' => $name, 'category' => 'Uniform', 'price' => $price,
            'per_student' => $cap, 'reorder_level' => 5, 'is_active' => true,
        ]);

        if ($level) {
            $item->gradeLevels()->sync([$level->id]);
        }

        if ($opening > 0) {
            StockMovement::create([
                'stock_item_id' => $item->id, 'direction' => 'IN', 'qty' => $opening,
                'description' => $name, 'note' => 'Opening stock',
                'occurred_on' => now()->toDateString(),
            ]);
        }

        return $item;
    }

    private function issueOne(int $qty = 1): void
    {
        $this->actingAs($this->storekeeper)
            ->postJson('/api/store/issue', [
                'student_id'    => $this->pupil7->id,
                'stock_item_id' => $this->uniform7->id,
                'qty'           => $qty,
            ])
            ->assertCreated();
    }
}
