<?php

/*
|--------------------------------------------------------------------------
| School store — book shop and uniform shop
|--------------------------------------------------------------------------
| Paste INSIDE the `Route::middleware('two-factor')->group(...)` block in
| routes/api.php.
|
| Three permissions, because the school asked for three different people:
|   store.view    everyone who may look at the shelf
|   store.manage  define items, record deliveries      — the Proprietress
|   store.issue   hand something to a pupil            — the store keeper
|
| The Proprietress does NOT hold store.issue and the store keeper does NOT
| hold store.manage. That is the request, not an oversight.
*/

use App\Http\Controllers\StoreController;
use Illuminate\Support\Facades\Route;

Route::middleware('permission:store.view')->group(function () {
    Route::get('/store/catalogue', [StoreController::class, 'catalogue']);
    Route::get('/store/report', [StoreController::class, 'dailyReport']);
    Route::get('/store/items/{item}/ledger', [StoreController::class, 'ledger']);
    Route::get('/store/students/{student}', [StoreController::class, 'forStudent']);
});

// The store keeper's one verb.
Route::post('/store/issue', [StoreController::class, 'issue'])
    ->middleware('permission:store.issue');

// The Proprietress's.
Route::middleware('permission:store.manage')->group(function () {
    Route::post('/store/receive', [StoreController::class, 'receive']);
    Route::post('/store/items', [StoreController::class, 'storeItem']);
    Route::patch('/store/items/{item}', [StoreController::class, 'updateItem']);
    Route::delete('/store/items/{item}', [StoreController::class, 'retireItem']);
});
