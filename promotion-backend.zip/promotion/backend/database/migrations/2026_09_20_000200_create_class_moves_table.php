<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * Every time a pupil changes class, and why.
 *
 * The structural truth already lives in `enrollments`: one row per pupil
 * per academic year, carrying the class they were in and how the year ended
 * for them. This table is the narrative — who moved whom, when, and on what
 * grounds — and it answers the question `enrollments` cannot: *why* is this
 * child in Grade 5 rather than repeating Grade 4?
 *
 * It covers both kinds of move:
 *   - year-end promotion, alongside a new enrollment row
 *   - a within-year transfer, where the enrollment's class simply changes
 *
 * Append-only. A move entered in error is corrected by a second move with a
 * reason, never by editing the first — so the trail shows the mistake and
 * the correction, which is what a parent asking "when did my child move?"
 * is actually owed.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('class_moves', function (Blueprint $table) {
            $table->id();
            $table->foreignId('student_id')->constrained()->cascadeOnDelete();

            // Nullable on the "from" side for a first admission, and on the
            // "to" side for a pupil who graduated or left.
            $table->foreignId('from_class_room_id')->nullable()
                ->constrained('class_rooms')->nullOnDelete();
            $table->foreignId('to_class_room_id')->nullable()
                ->constrained('class_rooms')->nullOnDelete();

            // Copied, not referenced. Rename or retire a class next year and
            // last year's record must still say what actually happened.
            $table->string('from_label', 80)->nullable();
            $table->string('to_label', 80)->nullable();

            // PROMOTION | REPEAT | TRANSFER | GRADUATE | WITHDRAW
            $table->string('reason', 16);
            $table->string('note', 200)->nullable();

            $table->foreignId('academic_year_id')->nullable()
                ->constrained()->nullOnDelete();

            $table->foreignId('moved_by')->nullable()
                ->constrained('users')->nullOnDelete();

            $table->date('moved_on');
            $table->timestamps();

            $table->index(['student_id', 'moved_on']);
            $table->index(['moved_on', 'reason']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('class_moves');
    }
};
