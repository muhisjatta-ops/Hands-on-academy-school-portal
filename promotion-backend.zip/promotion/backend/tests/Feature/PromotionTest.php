<?php

namespace Tests\Feature;

use App\Models\AcademicYear;
use App\Models\ClassMove;
use App\Models\ClassRoom;
use App\Models\Enrollment;
use App\Models\GradeLevel;
use App\Models\Student;
use App\Models\User;
use App\Services\Promoter;
use Database\Seeders\RolePermissionSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

/**
 * Promotion is the operation a school notices least and suffers most from.
 * These tests are mostly about what must NOT happen: no duplicate
 * enrollments, no half-finished batch, no silently rewritten history.
 */
class PromotionTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;
    private User $registrar;

    private AcademicYear $y1;
    private AcademicYear $y2;
    private GradeLevel $g4;
    private GradeLevel $g5;
    private ClassRoom $g4Blue;
    private ClassRoom $g5Blue;
    private ClassRoom $g4BlueNext;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RolePermissionSeeder::class);

        $this->admin = $this->userWith('admin');
        $this->registrar = $this->userWith('registrar');

        $this->y1 = AcademicYear::create([
            'name' => '2026/2027', 'start_date' => '2026-09-01',
            'end_date' => '2027-07-31', 'is_current' => true,
        ]);
        $this->y2 = AcademicYear::create([
            'name' => '2027/2028', 'start_date' => '2027-09-01',
            'end_date' => '2028-07-31', 'is_current' => false,
        ]);

        $this->g4 = GradeLevel::create(['name' => 'Grade 4', 'sequence' => 4]);
        $this->g5 = GradeLevel::create(['name' => 'Grade 5', 'sequence' => 5]);

        $this->g4Blue = $this->room($this->g4, $this->y1);
        $this->g5Blue = $this->room($this->g5, $this->y2);
        $this->g4BlueNext = $this->room($this->g4, $this->y2);  // for repeaters
    }

    /* --------------------------- permissions --------------------------- */

    public function test_the_administrator_may_promote(): void
    {
        $this->pupil('Ebrima', 'Camara');

        $this->actingAs($this->admin)
            ->getJson('/api/classes/' . $this->g4Blue->id . '/promotion')
            ->assertOk();
    }

    public function test_the_registrar_may_edit_pupils_but_not_promote_them(): void
    {
        $this->actingAs($this->registrar)
            ->getJson('/api/classes/' . $this->g4Blue->id . '/promotion')
            ->assertForbidden();

        $this->actingAs($this->registrar)
            ->postJson('/api/classes/' . $this->g4Blue->id . '/promotion', [
                'academic_year_id' => $this->y2->id,
                'outcomes' => [],
            ])
            ->assertForbidden();
    }

    public function test_a_teacher_cannot_promote(): void
    {
        $this->actingAs($this->userWith('teacher'))
            ->getJson('/api/classes/' . $this->g4Blue->id . '/promotion')
            ->assertForbidden();
    }

    /* ---------------------------- promoting ---------------------------- */

    public function test_promotion_creates_a_new_enrollment_and_leaves_the_old_one(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');

        $this->promote([$pupil->id => ClassMove::PROMOTION])->assertOk();

        // Last year's row survives, saying where they were and how it ended.
        $this->assertDatabaseHas('enrollments', [
            'student_id' => $pupil->id,
            'class_room_id' => $this->g4Blue->id,
            'academic_year_id' => $this->y1->id,
            'outcome' => 'PROMOTED',
        ]);

        // And there is a fresh row for the new year.
        $this->assertDatabaseHas('enrollments', [
            'student_id' => $pupil->id,
            'class_room_id' => $this->g5Blue->id,
            'academic_year_id' => $this->y2->id,
            'is_repeating' => false,
        ]);

        $this->assertSame(2, Enrollment::where('student_id', $pupil->id)->count());
    }

    public function test_every_move_is_recorded_with_a_reason_and_an_author(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');
        $this->promote([$pupil->id => ClassMove::PROMOTION])->assertOk();

        $move = ClassMove::where('student_id', $pupil->id)->firstOrFail();

        $this->assertSame(ClassMove::PROMOTION, $move->reason);
        $this->assertSame($this->admin->id, $move->moved_by);
        $this->assertSame('Grade 4 Blue', $move->from_label);
        $this->assertSame('Grade 5 Blue', $move->to_label);
    }

    public function test_a_renamed_class_does_not_rewrite_what_the_move_says(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');
        $this->promote([$pupil->id => ClassMove::PROMOTION])->assertOk();

        $this->g4Blue->update(['stream' => 'Red']);

        $this->assertSame(
            'Grade 4 Blue',
            ClassMove::where('student_id', $pupil->id)->value('from_label')
        );
    }

    public function test_repeating_keeps_the_level_but_moves_to_the_new_year(): void
    {
        $pupil = $this->pupil('Isatou', 'Bah');

        $this->promote([$pupil->id => ClassMove::REPEAT])->assertOk();

        $this->assertDatabaseHas('enrollments', [
            'student_id' => $pupil->id,
            'class_room_id' => $this->g4BlueNext->id,
            'academic_year_id' => $this->y2->id,
            'is_repeating' => true,
        ]);

        $this->assertDatabaseHas('enrollments', [
            'student_id' => $pupil->id,
            'academic_year_id' => $this->y1->id,
            'outcome' => 'REPEAT',
        ]);
    }

    public function test_graduating_and_leaving_change_the_status_and_open_no_new_year(): void
    {
        $grad = $this->pupil('Modou', 'Faal');
        $gone = $this->pupil('Binta', 'Sow');

        $this->promote([
            $grad->id => ClassMove::GRADUATE,
            $gone->id => ClassMove::WITHDRAW,
        ])->assertOk();

        $this->assertSame('GRADUATED', $grad->fresh()->status);
        $this->assertSame('WITHDRAWN', $gone->fresh()->status);

        $this->assertSame(1, Enrollment::where('student_id', $grad->id)->count());
        $this->assertSame(1, Enrollment::where('student_id', $gone->id)->count());
    }

    /* ------------------------- what must not happen ------------------------- */

    public function test_running_it_twice_skips_rather_than_duplicating(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');

        $this->promote([$pupil->id => ClassMove::PROMOTION])->assertOk();

        $second = $this->promote([$pupil->id => ClassMove::PROMOTION])->assertOk();

        $this->assertSame(0, $second->json('promoted'));
        $this->assertStringContainsString('already enrolled', $second->json('skipped.0'));
        $this->assertSame(2, Enrollment::where('student_id', $pupil->id)->count());
    }

    public function test_a_failure_part_way_through_rolls_the_whole_batch_back(): void
    {
        $ok = $this->pupil('Ebrima', 'Camara');
        $stranded = $this->pupil('Fatou', 'Njie');

        // No Grade 4 room exists in the new year, so the repeater cannot be
        // placed — and the pupil ahead of them in the list must not move
        // either, or the class ends up half promoted.
        $this->g4BlueNext->forceDelete();

        try {
            app(Promoter::class)->promote(
                $this->g4Blue, $this->g5Blue, $this->y2,
                [$ok->id => ClassMove::PROMOTION, $stranded->id => ClassMove::REPEAT]
            );
            $this->fail('Expected the batch to be refused.');
        } catch (ValidationException $e) {
            // expected
        }

        $this->assertSame(1, Enrollment::where('student_id', $ok->id)->count());
        $this->assertDatabaseCount('class_moves', 0);
    }

    public function test_promoting_into_the_same_year_is_refused(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');

        $this->actingAs($this->admin)
            ->postJson('/api/classes/' . $this->g4Blue->id . '/promotion', [
                'academic_year_id' => $this->y1->id,
                'to_class_room_id' => $this->g5Blue->id,
                'outcomes' => [$pupil->id => ClassMove::PROMOTION],
            ])
            ->assertStatus(422)
            ->assertJsonValidationErrors('academic_year_id');
    }

    public function test_a_target_class_from_the_wrong_year_is_refused_by_name(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');
        $wrongYearRoom = $this->room($this->g5, $this->y1);

        $response = $this->actingAs($this->admin)
            ->postJson('/api/classes/' . $this->g4Blue->id . '/promotion', [
                'academic_year_id' => $this->y2->id,
                'to_class_room_id' => $wrongYearRoom->id,
                'outcomes' => [$pupil->id => ClassMove::PROMOTION],
            ])
            ->assertStatus(422);

        $this->assertStringContainsString(
            '2026/2027', $response->json('errors.to_class_room_id.0')
        );
    }

    public function test_a_pupil_not_in_the_class_is_skipped_not_moved(): void
    {
        $elsewhere = $this->pupil('Outsider', 'Jallow', $this->room($this->g5, $this->y1));

        $result = $this->promote([$elsewhere->id => ClassMove::PROMOTION])->assertOk();

        $this->assertSame(0, $result->json('promoted'));
        $this->assertStringContainsString('not enrolled', $result->json('skipped.0'));
    }

    /* --------------------------- within the year --------------------------- */

    public function test_a_within_year_move_edits_the_enrollment_and_records_why(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');
        $other = $this->room($this->g4, $this->y1, 'Green');

        $this->actingAs($this->admin)
            ->postJson('/api/students/' . $pupil->id . '/move', [
                'to_class_room_id' => $other->id,
                'reason' => ClassMove::TRANSFER,
                'note' => 'Parent request',
            ])
            ->assertCreated();

        // Still ONE enrollment for the year — they were never in two classes.
        $this->assertSame(1, Enrollment::where('student_id', $pupil->id)->count());
        $this->assertSame($other->id, $pupil->currentEnrollment()->class_room_id);

        $move = ClassMove::where('student_id', $pupil->id)->firstOrFail();
        $this->assertSame('Parent request', $move->note);
        $this->assertSame('Grade 4 Blue', $move->from_label);
    }

    public function test_moving_a_pupil_into_the_class_they_are_already_in_is_refused(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');

        $this->actingAs($this->admin)
            ->postJson('/api/students/' . $pupil->id . '/move', [
                'to_class_room_id' => $this->g4Blue->id,
                'reason' => ClassMove::TRANSFER,
            ])
            ->assertStatus(422);
    }

    public function test_a_within_year_move_cannot_cross_into_another_year(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');

        $this->actingAs($this->admin)
            ->postJson('/api/students/' . $pupil->id . '/move', [
                'to_class_room_id' => $this->g5Blue->id,   // belongs to 2027/2028
                'reason' => ClassMove::TRANSFER,
            ])
            ->assertStatus(422)
            ->assertJsonValidationErrors('to_class_room_id');
    }

    /* ------------------------------ history ------------------------------ */

    public function test_class_history_reads_back_in_order(): void
    {
        $pupil = $this->pupil('Ebrima', 'Camara');
        $other = $this->room($this->g4, $this->y1, 'Green');

        $this->actingAs($this->admin)->postJson('/api/students/' . $pupil->id . '/move', [
            'to_class_room_id' => $other->id, 'reason' => ClassMove::TRANSFER,
        ])->assertCreated();

        $moves = $this->actingAs($this->admin)
            ->getJson('/api/students/' . $pupil->id . '/class-history')
            ->assertOk()
            ->json('moves');

        $this->assertCount(1, $moves);
        $this->assertSame('Moved within the year', $moves[0]['reason']);
        $this->assertSame($this->admin->name, $moves[0]['by']);
    }

    public function test_the_preview_warns_when_the_next_year_has_no_class(): void
    {
        $this->g5Blue->forceDelete();
        $this->pupil('Ebrima', 'Camara');

        $warnings = $this->actingAs($this->admin)
            ->getJson('/api/classes/' . $this->g4Blue->id . '/promotion')
            ->assertOk()
            ->json('warnings');

        $this->assertNotEmpty($warnings);
        $this->assertStringContainsString('no Grade 5 class', $warnings[0]);
    }

    /* ------------------------------ helpers ------------------------------ */

    private function userWith(string $role): User
    {
        $user = User::factory()->create();
        $user->assignRole($role);

        return $user;
    }

    private function room(GradeLevel $level, AcademicYear $year, string $stream = 'Blue'): ClassRoom
    {
        return ClassRoom::create([
            'grade_level_id' => $level->id,
            'academic_year_id' => $year->id,
            'stream' => $stream,
            'capacity' => 40,
        ]);
    }

    private function pupil(string $first, string $last, ?ClassRoom $room = null): Student
    {
        $student = Student::create([
            'admission_number' => 'HOA-' . fake()->unique()->numerify('####'),
            'first_name' => $first, 'last_name' => $last,
            'date_of_birth' => '2015-03-04', 'gender' => 'Male',
            'admission_date' => '2026-09-01', 'status' => 'ACTIVE',
        ]);

        Enrollment::create([
            'student_id' => $student->id,
            'class_room_id' => ($room ?? $this->g4Blue)->id,
            'academic_year_id' => ($room ?? $this->g4Blue)->academic_year_id,
            'date_enrolled' => '2026-09-01',
        ]);

        return $student;
    }

    private function promote(array $outcomes)
    {
        return $this->actingAs($this->admin)
            ->postJson('/api/classes/' . $this->g4Blue->id . '/promotion', [
                'academic_year_id' => $this->y2->id,
                'to_class_room_id' => $this->g5Blue->id,
                'outcomes' => $outcomes,
            ]);
    }
}
