<?php

namespace App\Services;

use App\Models\AcademicYear;
use App\Models\ClassMove;
use App\Models\ClassRoom;
use App\Models\Enrollment;
use App\Models\Student;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/**
 * End-of-year promotion.
 *
 * This is the most consequential operation in the system and the hardest to
 * undo: it moves a whole class at once, and a mistake is only noticed weeks
 * later when a child is sitting in the wrong room or a parent is quoted the
 * wrong fee. So it is written to be boring and reversible-by-inspection:
 *
 *   - the whole batch runs in ONE transaction. A half-promoted class, where
 *     eleven pupils moved and nine did not, is worse than none moving: it
 *     reads as finished and is wrong about the rest.
 *   - promotion CREATES a new enrollment for the new year rather than
 *     editing the old one. Last year's row keeps saying which class the
 *     pupil was in and how the year ended, which is what a transcript, a
 *     report card reprint and a fee query all depend on.
 *   - every move is also written to `class_moves` with a reason.
 *   - re-running is safe. A pupil who already has an enrollment for the
 *     target year is skipped and reported, not duplicated — the unique
 *     index would otherwise abort the entire batch over one stray row.
 */
class Promoter
{
    /**
     * @param  array<int,string>  $outcomes  student id => PROMOTION|REPEAT|GRADUATE|WITHDRAW
     * @return array{promoted:int,repeated:int,graduated:int,withdrawn:int,skipped:array}
     */
    public function promote(
        ClassRoom $from,
        ?ClassRoom $to,
        AcademicYear $toYear,
        array $outcomes,
        ?string $note = null
    ): array {
        $fromYear = $from->academicYear;

        if ($toYear->id === $fromYear->id) {
            $this->fail('academic_year_id',
                'The new year must be different from the one being closed.');
        }

        if ($to && $to->academic_year_id !== $toYear->id) {
            $this->fail('to_class_room_id', sprintf(
                '%s belongs to %s, not %s.',
                $to->name, $to->academicYear->name, $toYear->name
            ));
        }

        $needsTarget = collect($outcomes)->contains(ClassMove::PROMOTION);

        if ($needsTarget && ! $to) {
            $this->fail('to_class_room_id',
                'Choose the class the promoted pupils are moving into.');
        }

        $students = Student::whereIn('id', array_keys($outcomes))->get()->keyBy('id');

        $result = [
            'promoted' => 0, 'repeated' => 0, 'graduated' => 0,
            'withdrawn' => 0, 'skipped' => [],
        ];

        DB::transaction(function () use (
            $from, $to, $fromYear, $toYear, $outcomes, $students, $note, &$result
        ) {
            foreach ($outcomes as $studentId => $outcome) {
                $student = $students->get($studentId);

                if (! $student) {
                    $result['skipped'][] = "Student {$studentId} no longer exists.";
                    continue;
                }

                $enrollment = Enrollment::where('student_id', $student->id)
                    ->where('academic_year_id', $fromYear->id)
                    ->where('class_room_id', $from->id)
                    ->first();

                if (! $enrollment) {
                    $result['skipped'][] = "{$student->full_name} is not enrolled in {$from->name}.";
                    continue;
                }

                // Already handled — by an earlier run, or by someone else a
                // minute ago. Say so rather than making a second row.
                $already = Enrollment::where('student_id', $student->id)
                    ->where('academic_year_id', $toYear->id)
                    ->exists();

                if ($already && in_array($outcome, [ClassMove::PROMOTION, ClassMove::REPEAT], true)) {
                    $result['skipped'][] = "{$student->full_name} is already enrolled for {$toYear->name}.";
                    continue;
                }

                $this->applyOne($student, $enrollment, $from, $to, $toYear, $outcome, $note, $result);
            }
        });

        return $result;
    }

    private function applyOne(
        Student $student,
        Enrollment $enrollment,
        ClassRoom $from,
        ?ClassRoom $to,
        AcademicYear $toYear,
        string $outcome,
        ?string $note,
        array &$result
    ): void {
        $target = null;

        switch ($outcome) {
            case ClassMove::PROMOTION:
                $enrollment->update(['outcome' => 'PROMOTED']);
                $target = $to;
                $this->enroll($student, $to, $toYear, false);
                $result['promoted']++;
                break;

            case ClassMove::REPEAT:
                $enrollment->update(['outcome' => 'REPEAT']);
                // Repeating means the SAME grade level in the new year. The
                // class room itself belongs to a year, so the pupil needs
                // that level's room in the new year, not last year's room.
                $target = $this->sameLevelIn($from, $toYear);
                $this->enroll($student, $target, $toYear, true);
                $result['repeated']++;
                break;

            case ClassMove::GRADUATE:
                $enrollment->update(['outcome' => 'PROMOTED']);
                $student->update(['status' => 'GRADUATED']);
                $result['graduated']++;
                break;

            case ClassMove::WITHDRAW:
                $enrollment->update(['outcome' => 'LEFT']);
                $student->update(['status' => 'WITHDRAWN']);
                $result['withdrawn']++;
                break;

            default:
                $this->fail('outcomes', "Unknown outcome '{$outcome}'.");
        }

        ClassMove::create([
            'student_id'         => $student->id,
            'from_class_room_id' => $from->id,
            'to_class_room_id'   => $target?->id,
            'from_label'         => $from->name,
            'to_label'           => $target?->name
                ?? ($outcome === ClassMove::GRADUATE ? 'Graduated' : 'Left'),
            'reason'             => $outcome,
            'note'               => $note,
            'academic_year_id'   => $toYear->id,
            'moved_by'           => Auth::id(),
            'moved_on'           => now()->toDateString(),
        ]);
    }

    private function enroll(Student $student, ?ClassRoom $room, AcademicYear $year, bool $repeating): void
    {
        if (! $room) {
            $this->fail('to_class_room_id',
                "No class for {$student->full_name} in {$year->name}. Create it first.");
        }

        Enrollment::create([
            'student_id'       => $student->id,
            'class_room_id'    => $room->id,
            'academic_year_id' => $year->id,
            'date_enrolled'    => now()->toDateString(),
            'is_repeating'     => $repeating,
        ]);
    }

    /** The same grade level's room in the new year. */
    private function sameLevelIn(ClassRoom $room, AcademicYear $year): ?ClassRoom
    {
        return ClassRoom::where('grade_level_id', $room->grade_level_id)
            ->where('academic_year_id', $year->id)
            ->orderByRaw('CASE WHEN stream = ? THEN 0 ELSE 1 END', [$room->stream])
            ->first();
    }

    /**
     * Move one pupil inside the year they are already in — a correction, a
     * parent's request, or a child placed in the wrong room on admission.
     *
     * Unlike promotion this edits the existing enrollment, because it is the
     * same year: the pupil was never in two classes at once, and pretending
     * otherwise would break the one-row-per-year rule the rest of the system
     * relies on. The move is still recorded, with a reason, because the
     * enrollment alone cannot say why the class changed.
     */
    public function transfer(Student $student, ClassRoom $to, string $reason, ?string $note = null): ClassMove
    {
        $enrollment = $student->currentEnrollment();

        if (! $enrollment) {
            $this->fail('student_id',
                "{$student->full_name} has no enrollment for the current year.");
        }

        if ($enrollment->class_room_id === $to->id) {
            $this->fail('to_class_room_id', "{$student->full_name} is already in {$to->name}.");
        }

        if ($to->academic_year_id !== $enrollment->academic_year_id) {
            $this->fail('to_class_room_id',
                'That class belongs to a different academic year. Use promotion instead.');
        }

        return DB::transaction(function () use ($student, $enrollment, $to, $reason, $note) {
            $from = $enrollment->classRoom;
            $enrollment->update(['class_room_id' => $to->id]);

            return ClassMove::create([
                'student_id'         => $student->id,
                'from_class_room_id' => $from?->id,
                'to_class_room_id'   => $to->id,
                'from_label'         => $from?->name,
                'to_label'           => $to->name,
                'reason'             => $reason,
                'note'               => $note,
                'academic_year_id'   => $enrollment->academic_year_id,
                'moved_by'           => Auth::id(),
                'moved_on'           => now()->toDateString(),
            ]);
        });
    }

    /** The default outcome to offer for each pupil in a class. */
    public function suggest(ClassRoom $room): string
    {
        return $room->gradeLevel?->nextLevel() ? ClassMove::PROMOTION : ClassMove::GRADUATE;
    }

    private function fail(string $field, string $message): void
    {
        throw ValidationException::withMessages([$field => $message]);
    }
}
