<?php

namespace App\Http\Controllers;

use App\Models\AcademicYear;
use App\Models\ClassMove;
use App\Models\ClassRoom;
use App\Models\Invoice;
use App\Models\Student;
use App\Services\Promoter;
use Illuminate\Http\Request;

class PromotionController
{
    public function __construct(private Promoter $promoter)
    {
    }

    /**
     * The class as it stands, with the default outcome for each pupil and
     * what they still owe.
     *
     * The balance is shown but never enforced. Whether a debt blocks
     * promotion is the school's decision, not the software's — and a system
     * that silently held a child back over unpaid fees would be making that
     * decision on the school's behalf, in the worst possible way.
     */
    public function preview(Request $request, ClassRoom $classRoom)
    {
        $suggested = $this->promoter->suggest($classRoom);
        $nextLevel = $classRoom->gradeLevel?->nextLevel();

        $nextYear = AcademicYear::where('start_date', '>', $classRoom->academicYear->start_date)
            ->orderBy('start_date')->first();

        $students = $classRoom->students()
            ->orderBy('last_name')->orderBy('first_name')
            ->get();

        return response()->json([
            'class_room' => [
                'id'   => $classRoom->id,
                'name' => $classRoom->name,
                'year' => $classRoom->academicYear->name,
            ],
            'next_level' => $nextLevel?->only(['id', 'name']),
            'next_year'  => $nextYear?->only(['id', 'name']),
            // Rooms in the new year that promoted pupils could move into.
            'targets'    => $nextYear && $nextLevel
                ? ClassRoom::where('academic_year_id', $nextYear->id)
                    ->where('grade_level_id', $nextLevel->id)
                    ->get()
                    ->map(fn (ClassRoom $c) => ['id' => $c->id, 'name' => $c->name])
                : [],
            'reasons'    => ClassMove::REASONS,
            'rows'       => $students->map(fn (Student $s) => [
                'student_id' => $s->id,
                'name'       => $s->full_name,
                'admission_number' => $s->admission_number,
                'suggested'  => $suggested,
                'owing'      => $this->owedBy($s),
            ]),
            'warnings'   => $this->warnings($classRoom, $nextYear, $nextLevel),
        ]);
    }

    public function apply(Request $request, ClassRoom $classRoom)
    {
        $reasons = implode(',', [
            ClassMove::PROMOTION, ClassMove::REPEAT,
            ClassMove::GRADUATE, ClassMove::WITHDRAW,
        ]);

        $data = $request->validate([
            'academic_year_id'  => ['required', 'exists:academic_years,id'],
            'to_class_room_id'  => ['nullable', 'exists:class_rooms,id'],
            'note'              => ['nullable', 'string', 'max:200'],
            'outcomes'          => ['required', 'array', 'min:1'],
            'outcomes.*'        => ['required', 'in:' . $reasons],
        ]);

        $result = $this->promoter->promote(
            $classRoom,
            $data['to_class_room_id'] ? ClassRoom::findOrFail($data['to_class_room_id']) : null,
            AcademicYear::findOrFail($data['academic_year_id']),
            $data['outcomes'],
            $data['note'] ?? null
        );

        return response()->json([
            'message' => sprintf(
                '%d promoted, %d repeating, %d graduated, %d left.',
                $result['promoted'], $result['repeated'],
                $result['graduated'], $result['withdrawn']
            ),
        ] + $result);
    }

    /** Move one pupil inside the current year. */
    public function transfer(Request $request, Student $student)
    {
        $data = $request->validate([
            'to_class_room_id' => ['required', 'exists:class_rooms,id'],
            'reason'           => ['required', 'in:' . ClassMove::TRANSFER . ',' . ClassMove::REPEAT],
            'note'             => ['nullable', 'string', 'max:200'],
        ]);

        $move = $this->promoter->transfer(
            $student,
            ClassRoom::findOrFail($data['to_class_room_id']),
            $data['reason'],
            $data['note'] ?? null
        );

        return response()->json([
            'message' => "{$student->full_name} moved to {$move->to_label}.",
        ], 201);
    }

    /** One pupil's class history — every move, newest first. */
    public function history(Student $student)
    {
        return response()->json([
            'student' => ['id' => $student->id, 'name' => $student->full_name],
            'moves'   => ClassMove::where('student_id', $student->id)
                ->with('mover:id,name')
                ->orderByDesc('moved_on')->orderByDesc('id')
                ->get()
                ->map(fn (ClassMove $m) => [
                    'date'   => $m->moved_on->toDateString(),
                    'from'   => $m->from_label,
                    'to'     => $m->to_label,
                    'reason' => $m->reasonLabel(),
                    'note'   => $m->note,
                    'by'     => $m->mover?->name,
                ]),
        ]);
    }

    /** Everything that moved on a given day, for the office's own check. */
    public function recent(Request $request)
    {
        $data = $request->validate([
            'from' => ['nullable', 'date'],
            'to'   => ['nullable', 'date', 'after_or_equal:from'],
        ]);

        return response()->json([
            'moves' => ClassMove::query()
                ->when($data['from'] ?? null, fn ($q, $d) => $q->where('moved_on', '>=', $d))
                ->when($data['to'] ?? null, fn ($q, $d) => $q->where('moved_on', '<=', $d))
                ->with(['student:id,first_name,last_name', 'mover:id,name'])
                ->orderByDesc('moved_on')->orderByDesc('id')
                ->limit(500)
                ->get()
                ->map(fn (ClassMove $m) => [
                    'date'    => $m->moved_on->toDateString(),
                    'student' => $m->student?->full_name ?? 'Removed pupil',
                    'from'    => $m->from_label,
                    'to'      => $m->to_label,
                    'reason'  => $m->reasonLabel(),
                    'by'      => $m->mover?->name,
                ]),
        ]);
    }

    /** What this pupil still owes, across every invoice raised. */
    private function owedBy(Student $student): float
    {
        return (float) Invoice::where('student_id', $student->id)
            ->get()
            ->sum(fn (Invoice $i) => max(0, $i->balance()));
    }

    private function warnings(ClassRoom $room, ?AcademicYear $nextYear, $nextLevel): array
    {
        $out = [];

        if (! $nextYear) {
            $out[] = 'No academic year follows ' . $room->academicYear->name
                . '. Create it before promoting anyone.';
        }

        if (! $nextLevel) {
            $out[] = $room->gradeLevel?->name
                . ' is the top level, so its pupils graduate rather than move up.';
        }

        if ($nextYear && $nextLevel) {
            $rooms = ClassRoom::where('academic_year_id', $nextYear->id)
                ->where('grade_level_id', $nextLevel->id)->count();

            if ($rooms === 0) {
                $out[] = 'There is no ' . $nextLevel->name . ' class in '
                    . $nextYear->name . ' yet. Create it before promoting.';
            }
        }

        return $out;
    }
}
