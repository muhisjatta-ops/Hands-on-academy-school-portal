<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClassMove extends Model
{
    public const PROMOTION = 'PROMOTION';
    public const REPEAT    = 'REPEAT';
    public const TRANSFER  = 'TRANSFER';
    public const GRADUATE  = 'GRADUATE';
    public const WITHDRAW  = 'WITHDRAW';

    public const REASONS = [
        self::PROMOTION => 'Promoted to the next level',
        self::REPEAT    => 'Repeating this level',
        self::TRANSFER  => 'Moved within the year',
        self::GRADUATE  => 'Completed the top level',
        self::WITHDRAW  => 'Left the school',
    ];

    protected $fillable = [
        'student_id', 'from_class_room_id', 'to_class_room_id',
        'from_label', 'to_label', 'reason', 'note',
        'academic_year_id', 'moved_by', 'moved_on',
    ];

    protected $casts = ['moved_on' => 'date'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

    public function mover()
    {
        return $this->belongsTo(User::class, 'moved_by');
    }

    public function reasonLabel(): string
    {
        return self::REASONS[$this->reason] ?? $this->reason;
    }
}
