<?php

/*
|--------------------------------------------------------------------------
| Promotion and class moves
|--------------------------------------------------------------------------
| Paste INSIDE the `Route::middleware('two-factor')->group(...)` block in
| routes/api.php.
|
| `students.promote` is its own permission, held only by the administrator.
| It is deliberately NOT part of `students.update`: a clerk who may correct
| a spelling should not be able to move a year group, and the two are asked
| for by different people at different times of the year.
|
| IMPORTANT: delete the old transfer route from api-phase2.php —
|   Route::post('/students/{student}/transfer', [StudentController::class, 'transfer'])
| It edits the enrollment with no record of the previous class and no
| reason. The replacement below is the same operation with a trail.
*/

use App\Http\Controllers\PromotionController;
use Illuminate\Support\Facades\Route;

Route::middleware('permission:students.promote')->group(function () {
    Route::get('/classes/{classRoom}/promotion', [PromotionController::class, 'preview']);
    Route::post('/classes/{classRoom}/promotion', [PromotionController::class, 'apply']);
    Route::post('/students/{student}/move', [PromotionController::class, 'transfer']);
});

// Reading a pupil's class history needs only the right to see the pupil.
Route::middleware('permission:students.view')->group(function () {
    Route::get('/students/{student}/class-history', [PromotionController::class, 'history']);
    Route::get('/class-moves', [PromotionController::class, 'recent']);
});
